# The Three Laws of the Existence-Mirror

## Law I — Intention Is Non-Observable  
AI cannot access intention; it must infer.

## Law II — Morality Cannot Be Proven  
Ethics arise from emotional & social cognition.

## Law III — Good/Evil Are Dynamic Variables  
Moral judgment shifts with context and relationship.
