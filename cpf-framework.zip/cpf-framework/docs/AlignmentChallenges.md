# Alignment Challenges in Post-LLM Systems

- RLHF cannot handle cross-domain conflict  
- Filters fail in high-context prompts  
- Scaling context is computationally unsustainable  
- LLMs do not understand relationships  
