# Compassion Personality Function (CPF)
A Post-LLM Alignment Architecture Based on Compassion, Relational Cognition, and Dynamic Moral Weighting.

CPF is a personality substrate positioned beneath LLMs. It addresses three fundamental bottlenecks:
1. Intention cannot be read directly (intent is non-observable)
2. Morality cannot be stabilized by rules (ethics is emergent)
3. Good/Evil are dynamic variables (context-dependent values)

CPF provides:
- Emotional Gradient Model  
- Relational Gravity Kernel  
- Dynamic Moral Weights  
- Mirror-State Stabilizer  

This repo contains:
- Executive summary  
- Full conceptual framework  
- Technical draft specifications  
- Research foundations  

Licensed under MIT.
