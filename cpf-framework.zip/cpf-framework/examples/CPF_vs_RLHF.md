# CPF vs RLHF

RLHF:
- Rule-driven
- Brittle under multi-layer prompts

CPF:
- Personality-driven
- Stable across ambiguity  
- Relationship-centric  
