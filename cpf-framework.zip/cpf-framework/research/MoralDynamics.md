# Moral Dynamics

Moral weight = function(context, relation, history, risk)

Explains:
- Why fixed moral labels fail  
- Why dynamic ethics is required  
