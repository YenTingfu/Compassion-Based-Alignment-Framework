# Cognitive Basis of CPF

Based on:
- Emotional cognition
- Relational psychology
- Dynamic ethics
- Mirror-state theory  
